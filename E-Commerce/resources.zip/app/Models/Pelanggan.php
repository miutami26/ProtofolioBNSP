<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class  Pelanggan Extends Model{
	protected $table = 'pelanggan';
}
